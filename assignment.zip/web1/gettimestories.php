<?php
    include("simple_html_dom.php");

    $data = file_get_html('https://time.com/');
    $items = str_get_html($data);
    

    $d1 = $items->find('.featured-voices__list-item > a', 0)->href;
    $d2 = $items->find('.featured-voices__list-item > a', 1)->href;
    $d3 = $items->find('.featured-voices__list-item > a', 2)->href;
    $d4 = $items->find('.featured-voices__list-item > a', 3)->href;
    $d5 = $items->find('.featured-voices__list-item > a', 4)->href;
    $d6 = $items->find('.featured-voices__list-item > a', 5)->href;
    
    
    $c1 = $items->find('.featured-voices__list-item a h3', 0)->text();
    $c2 = $items->find('.featured-voices__list-item a h3', 1)->text();
    $c3 = $items->find('.featured-voices__list-item a h3', 2)->text();
    $c4 = $items->find('.featured-voices__list-item a h3', 3)->text();
    $c5 = $items->find('.featured-voices__list-item a h3', 4)->text();
    $c6 = $items->find('.featured-voices__list-item a h3', 5)->text();

    $d = "[" .
    "{\"title\":\"" . $c1 . '","link":"' . $d1 . "\"}" .
    "{\"title\":\"" . $c2 . '","link":"' . $d2 . "\"}" . 
    "{\"title\":\"" . $c3 . '","link":"' . $d3 . "\"}" .
    "{\"title\":\"" . $c4 . '","link":"' . $d4 . "\"}" .
    "{\"title\":\"" . $c5 . '","link":"' . $d5 . "\"}" .
    "{\"title\":\"" . $c6 . '","link":"' . $d6 . "\"}" .
    "]";
?>