<?php
    include("gettimestories.php");
    echo $d;
?>